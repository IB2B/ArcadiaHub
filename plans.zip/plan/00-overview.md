# ArcadiaHub — Project Overview

## What Is ArcadiaHub?

**ArcadiaHub** is a B2B partner portal built for **Harlock**, an Italian company in the renewable energy / solar industry. It serves as the single digital hub where Harlock's external business partners can:

- Submit and track commercial **cases** (pratiche) with full lifecycle history
- Access **training content** through an integrated academy
- Browse and register for **events** (workshops, webinars, trainings)
- Download official **documents** (contracts, brand kits, guidelines)
- Read the company **blog** for news and industry insights
- Connect with other partners through a **community directory**
- Receive **real-time notifications** about case updates, new content, and events

## Target Users & Roles

| Role | Description | Access |
|------|-------------|--------|
| **PARTNER** | External agents and installers | Own cases, published content, events, academy, community, profile |
| **COMMERCIAL** | Harlock internal sales staff | All cases, admin panel, can create sub-user accounts |
| **ADMIN** | Harlock administrators | Full access — publish content, approve/reject partner applications, manage platform |

## Architecture

**Next.js 16 + Supabase** — a single full-stack application. There is no separate backend service.

- **Next.js Server Components** serve SSR pages
- **Next.js Server Actions** (`src/lib/data/`) handle all mutations — they replace REST endpoints
- **Supabase** provides: PostgreSQL database, GoTrue authentication, file storage buckets, and Realtime subscriptions
- **Resend** handles all transactional email
- **Vercel** hosts the application

> **Why not Spring Boot?** Supabase already provides everything Spring Boot would add (auth, managed DB, storage, real-time) at no extra cost and with no second deployment to maintain. See `01-stack-options.md`.

## Platform Modules

| Module | Description |
|--------|-------------|
| Cases | Partners submit service requests; commercial team manages lifecycle |
| Events | Admin publishes events; partners register; calendar view |
| Academy | Training content library with completion tracking |
| Documents | Technical document library with download tracking |
| Blog | Company news and articles with category filtering |
| Community | Partner directory (region, certifications, services) |
| Notifications | Real-time alert feed via Supabase Realtime |
| Admin Panel | Full management UI for COMMERCIAL and ADMIN roles |

## Current Implementation Status

The codebase is a **partial implementation** — routing, auth, UI components, and admin panel shell are solid, but several features are incomplete and bugs exist that cause runtime failures.

### Working
- Login, logout, password reset
- Case list, creation, status updates
- Event / academy / document / blog list and detail pages
- Admin CRUD for all content types
- Community / partner directory
- Middleware auth guards

### Incomplete or Broken
- `event_registrations` and `content_completions` DB tables missing from migrations → runtime SQL crashes
- Event registration flow not implemented
- Academy completion tracking not implemented
- Case status changes produce duplicate `case_history` rows (trigger + manual insert both fire)
- Email wired for one flow only (welcome email on approval); 6 other flows not connected
- Notifications page has no `page.tsx` — links go to a 404
- View counts use a read-then-write JS pattern (race condition)
- Dashboard activity feed executes 5 separate queries + client-side sort (N+1)
- Sub-user creation, suggestion inbox, comments, @mentions: not started
- Italian and French translations: partial

See `docs/arcadia-hub-project-plan.tex` for the full audit report and 4-week rebuild plan.

## Company Context

- **Company**: Harlock — Italian renewable energy company
- **Primary market**: Italy (with French- and English-speaking partners)
- **Brand color**: `#244675`
- **Font**: Outfit (Google Fonts)
