# UI Design System — Complete Reference

Custom component library for ArcadiaHub. No shadcn/ui, no Radix UI — all components built from scratch using Tailwind CSS v4 and CSS variables.

---

## Typography

### Font Family
- **Primary**: `'Outfit'` (Google Fonts) — weights: 300, 400, 500, 600, 700, 800
- **Fallback**: `system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif`

### Import
```css
@import url('https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&display=swap');
```

---

## Theme System

ArcadiaHub supports **2 themes** (light/dark), switchable at runtime via `data-theme` attribute on the `<html>` element. Theme preference is stored in localStorage.

> Note: The UI doc previously described 3 themes (C1/C2/C3). The actual implementation uses `light` and `dark`.

### Theme Variables — Light (default)
| Variable | Value | Usage |
|----------|-------|-------|
| `--primary` | `#244675` | Brand blue, buttons, links |
| `--primary-hover` | `#1a3457` | Button hover state |
| `--primary-light` | `#d0dae8` | Light blue backgrounds |
| `--secondary` | `#132640` | Dark blue accents |
| `--background` | `#F8FAFC` | Page background |
| `--card` | `#FFFFFF` | Card backgrounds |
| `--card-hover` | `#F1F5F9` | Card hover state |
| `--sidebar-bg` | `#FFFFFF` | Sidebar background |
| `--header-bg` | `#FFFFFF` | Header background |
| `--text` | `#1E293B` | Primary text |
| `--text-secondary` | `#475569` | Secondary text |
| `--text-muted` | `#64748B` | Muted/placeholder text |
| `--border` | `#E2E8F0` | Default borders |
| `--border-focus` | `#244675` | Focus ring color |
| `--success` | `#10B981` | Green |
| `--success-light` | `#D1FAE5` | Light green bg |
| `--warning` | `#F59E0B` | Amber |
| `--warning-light` | `#FEF3C7` | Light amber bg |
| `--error` | `#EF4444` | Red |
| `--error-light` | `#FEE2E2` | Light red bg |

### Theme Switching
```html
<html data-theme="light">  <!-- or "dark" -->
```
```typescript
// useTheme hook in src/hooks/useTheme.ts
function setTheme(theme: 'light' | 'dark') {
  document.documentElement.setAttribute('data-theme', theme);
  localStorage.setItem('theme', theme);
}
```

**Rule**: Always use CSS variables, never hardcode hex values. This is enforced as a project rule in CLAUDE.md.

---

## Shadows

| Variable | Value |
|----------|-------|
| `--shadow-sm` | `0 1px 2px 0 rgba(0,0,0,0.05)` |
| `--shadow` | `0 1px 3px 0 rgba(0,0,0,0.1)` |
| `--shadow-md` | `0 4px 6px -1px rgba(0,0,0,0.1)` |
| `--shadow-lg` | `0 10px 15px -3px rgba(0,0,0,0.1)` |

---

## Gradients

| Variable | Value |
|----------|-------|
| `--gradient-primary` | `linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%)` |
| `--gradient-accent` | `linear-gradient(135deg, var(--accent) 0%, var(--primary) 100%)` |

---

## Custom UI Component Library

All components live in `src/components/ui/`. Each uses CSS variables for theming.

### Button (`src/components/ui/Button.tsx`)
**Variants**: `primary`, `secondary`, `outline`, `ghost`, `danger`
**Sizes**: `sm`, `md`, `lg`

```
Primary:   bg-[var(--primary)] text-white hover:bg-[var(--primary-hover)]
Secondary: bg-[var(--card)] text-[var(--text)] border-[var(--border)]
Outline:   border-2 border-[var(--primary)] text-[var(--primary)]
Ghost:     text-[var(--text-muted)] hover:bg-[var(--card-hover)]
Danger:    bg-[var(--error)] text-white
```

States: Loading spinner + disabled (opacity-50)

### Card (`src/components/ui/Card.tsx`)
```
bg-[var(--card)] border border-[var(--border)] rounded-xl shadow-sm
```
Hover: `shadow-md` + optional branded border

### Input (`src/components/ui/Input.tsx`)
```
bg-[var(--card)] border border-[var(--border)] rounded-lg px-3 py-2
Focus: border-[var(--border-focus)] ring-2 ring-[var(--primary)]/20
Error: border-[var(--error)]
```
Includes label and error message slots.

### Select (`src/components/ui/Select.tsx`)
Custom styled with native `<select>` + custom arrow SVG (appearance: none).

### Modal (`src/components/ui/Modal.tsx`)
- Backdrop: `bg-black/50` with `backdrop-blur`
- Container: `bg-[var(--card)] rounded-2xl shadow-xl max-w-lg`
- Sections: Header (title + close), Body, Footer
- Animation: `animate-fadeIn` (0.3s ease-out)

### Table (`src/components/ui/Table.tsx`)
- Header: `bg-[var(--card-hover)] text-[var(--text-muted)] text-xs uppercase`
- Rows: `hover:bg-[var(--card-hover)] border-b border-[var(--border)]`
- Responsive: Horizontally scrollable on mobile

### Tabs (`src/components/ui/Tabs.tsx`)
- `border-b border-[var(--border)]`
- Active: `border-b-2 border-[var(--primary)] text-[var(--primary)]`
- Inactive: `text-[var(--text-muted)]`

### Badge (`src/components/ui/Badge.tsx`)
Rounded-full pill shapes. Color variants tied to status:
- `PENDING`: warning-light bg + warning text
- `IN_PROGRESS`: info-light bg + info text
- `COMPLETED`: success-light bg + success text
- `CANCELLED`: error-light bg + error text
- `SUSPENDED`: gray bg + gray text

### Avatar (`src/components/ui/Avatar.tsx`)
Circular image with fallback initials. Sizes: `sm` (8), `md` (10), `lg` (12), `xl` (16). Fallback: `bg-[var(--primary-light)] text-[var(--primary)]`.

### Pagination (`src/components/ui/Pagination.tsx`)
`« First | ‹ Prev | 1 2 3 ... | Next › | Last »`
Active page: `bg-[var(--primary)] text-white`. Shows "Showing X to Y of Z results".

### FileUpload (`src/components/ui/FileUpload.tsx`)
Drag-and-drop zone with dashed border. Shows file type/size constraints, upload progress, and image preview.

### Textarea (`src/components/ui/Textarea.tsx`)
Multi-line input, same styling as Input, with optional character count.

### Toggle (`src/components/ui/Toggle.tsx`)
Switch control. Active: `bg-[var(--primary)]`. Inactive: `bg-gray-200`.

### ErrorDisplay (`src/components/ui/ErrorDisplay.tsx`)
Error boundary component: error icon, title, message, "Try Again" button.

### PageSkeleton (`src/components/ui/PageSkeleton.tsx`)
Pre-built skeletons for every page type using `animate-pulse`:
| Skeleton | Usage |
|----------|-------|
| `DashboardPageSkeleton` | Dashboard page |
| `ListPageSkeleton` | List/table pages |
| `AdminPageSkeleton` | Admin pages |
| `CardSkeleton` | Content cards |
| `TableRowSkeleton` | Table rows |

---

## Animations

```css
@keyframes fadeIn  { from { opacity: 0; } to { opacity: 1; } }
@keyframes slideUp { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
@keyframes slideIn { from { opacity: 0; transform: translateX(-10px); } to { opacity: 1; transform: translateX(0); } }
```

Utility classes: `.animate-fadeIn`, `.animate-slideUp`, `.animate-slideIn`

---

## Responsive Design

### Breakpoints
| Name | Width | Usage |
|------|-------|-------|
| `sm` | 640px | Small |
| `md` | 768px | Tablet |
| `lg` | 1024px | Desktop |
| `xl` | 1280px | Large desktop |

### Layout Strategy
- **Mobile (< 768px)**: Single column, bottom navigation bar
- **Desktop (≥ 1024px)**: Full sidebar (240px) + content layout

### Dashboard Layout
```
Desktop:
┌─────────────────────────────────────────────┐
│              Header (64px)                   │
├─────────┬───────────────────────────────────┤
│ Sidebar │         Content Area               │
│ (240px) │         (flex-1, scrollable)        │
└─────────┴───────────────────────────────────┘

Mobile:
┌─────────────────────────────┐
│         Header (56px)        │
├─────────────────────────────┤
│     Content (scrollable)     │
├─────────────────────────────┤
│     Bottom Nav (60px)        │
│  Dashboard Cases Events ...  │
└─────────────────────────────┘
```

### Bottom Nav (Mobile)
- 5 tabs: Dashboard, Cases, Events, Academy, More
- "More" expands: Documents, Blog, Community, Profile, Settings
- Touch-optimized tap targets
- Safe area insets: `env(safe-area-inset-bottom)`

---

## Scrollbar Styling

Custom scrollbars via CSS:
- Track: `var(--card-hover)`
- Thumb: `var(--text-muted)` → hover: `var(--text-secondary)` → active: `var(--primary)`
- Border radius: 6px

---

## Focus Styles

```css
:focus-visible {
  outline: 2px solid var(--primary);
  outline-offset: 2px;
}
```

Applied globally to all interactive elements.

---

## Utility Classes

| Class | Effect |
|-------|--------|
| `.gradient-text` | Text with primary gradient clip |
| `.gradient-bg` | Primary gradient background |
| `.glass-effect` | Frosted glass (bg + backdrop-filter) |
| `.card` | Standard card (bg + border + shadow + transition) |
