# Pages & Routing — Complete Reference

Every page in ArcadiaHub with its route pattern, data requirements, and access control.

---

## Routing Architecture

### URL Pattern
All routes are prefixed with `/{locale}/` where locale is `en`, `it`, or `fr`.

```
https://arcadiahub.com/{locale}/{path}

Examples:
  /en/dashboard
  /it/cases/uuid-here
  /fr/admin/partners
```

### Route Groups (Next.js App Router)
```
src/app/
  not-found.tsx             ← Global 404 (root)

  [locale]/
    layout.tsx              ← Locale layout (NextIntlClientProvider, theme attribute)
    page.tsx                ← Landing page (public)
    not-found.tsx           ← Locale-aware 404

    (auth)/                 ← Auth route group (no shared layout)
      login/
        page.tsx
      forgot-password/
        page.tsx
      reset-password/
        page.tsx
      request-access/
        page.tsx

    (dashboard)/            ← Protected — requires Supabase session
      layout.tsx            ← AppShell: Header + Sidebar + BottomNav
      dashboard/
        page.tsx
        loading.tsx
        error.tsx
      cases/
        page.tsx
        loading.tsx
        error.tsx
        [id]/
          page.tsx
          loading.tsx
          error.tsx
      events/
        page.tsx
        loading.tsx
        error.tsx
        [id]/
          page.tsx
          loading.tsx
          error.tsx
      academy/
        page.tsx
        loading.tsx
        error.tsx
        [id]/
          page.tsx
          loading.tsx
          error.tsx
      documents/
        page.tsx
        loading.tsx
        error.tsx
        [id]/
          page.tsx
          loading.tsx
          error.tsx
      blog/
        page.tsx
        loading.tsx
        error.tsx
        [slug]/
          page.tsx
          loading.tsx
          error.tsx
      community/
        page.tsx
        loading.tsx
        error.tsx
        [id]/
          page.tsx
          loading.tsx
          error.tsx
      notifications/
        ⚠️ page.tsx MISSING (Bug 9)
        error.tsx
      activity/
        page.tsx
        loading.tsx
        error.tsx
      profile/
        page.tsx
        loading.tsx
        error.tsx
      settings/
        page.tsx
        loading.tsx
        error.tsx

    (admin)/                ← Protected — requires ADMIN or COMMERCIAL role
      admin/
        layout.tsx          ← Admin shell (server-side role gate)
        loading.tsx
        error.tsx
        partners/
          page.tsx
          loading.tsx
          error.tsx
        cases/
          page.tsx
          loading.tsx
          error.tsx
          new/
            page.tsx
        events/
          page.tsx
          loading.tsx
          error.tsx
        academy/
          page.tsx
          loading.tsx
          error.tsx
        documents/
          page.tsx
          loading.tsx
          error.tsx
        blog/
          page.tsx
          loading.tsx
          error.tsx
        access-requests/
          page.tsx
          loading.tsx
          error.tsx
```

---

## Public Pages (No Auth Required)

| Route | Page | Purpose | Data Source |
|-------|------|---------|-------------|
| `/{locale}` | Landing | Marketing page | Static + i18n |
| `/{locale}/login` | Login | Authentication | — |
| `/{locale}/forgot-password` | Forgot Password | Request reset email | — |
| `/{locale}/reset-password` | Reset Password | Set new password via token | Token from URL params |
| `/{locale}/request-access` | Access Request | Application form | File upload optional |

---

## Dashboard Pages (Auth Required — All Roles)

| Route | Page | Data Functions | Components |
|-------|------|----------------|------------|
| `/{locale}/dashboard` | Dashboard | `getCaseStats()`, `getMyCases({limit:5})`, `getActivityFeed()` | StatsCard, TimelineFeed |
| `/{locale}/cases` | Case List | `getMyCases({search, status, page})`, `getCaseStats()` | CaseFilters, Pagination |
| `/{locale}/cases/[id]` | Case Detail | `getMyCase(id)` | CaseTimeline |
| `/{locale}/events` | Event List | `getEvents({type, page, search})` | EventCard, CalendarView, Tabs |
| `/{locale}/events/[id]` | Event Detail | `getEvent(id)` | — |
| `/{locale}/academy` | Academy List | `getAcademyContent({type, search, page})` | Card grid, filters |
| `/{locale}/academy/[id]` | Academy Detail | `getAcademyItem(id)`, `getMyCompletions()` | Media player |
| `/{locale}/documents` | Document List | `getDocuments({category, search, page})` | Category tabs |
| `/{locale}/documents/[id]` | Document Detail | `getDocument(id)` | DocumentPreview |
| `/{locale}/blog` | Blog List | `getBlogPosts({category, search, page})` | Card grid |
| `/{locale}/blog/[slug]` | Blog Detail | `getBlogPost(slug)` | Article layout |
| `/{locale}/community` | Community | `getPartners({search, page})` | PartnerCard, alphabet filter |
| `/{locale}/community/[id]` | Partner Profile | `getPartnerProfile(id)` | Profile layout |
| `/{locale}/notifications` | Notifications | `getNotifications()` | ⚠️ page.tsx missing (Bug 9) |
| `/{locale}/activity` | Activity Feed | `getActivityFeed()` | TimelineFeed |
| `/{locale}/profile` | My Profile | `getProfile()` | Profile form, FileUpload |
| `/{locale}/settings` | Settings | `getProfile()` | Theme picker, LanguageSwitcher |

---

## Admin Pages (Auth Required — ADMIN/COMMERCIAL Only)

Role check is performed server-side in `(admin)/admin/layout.tsx` using `requireRole(['ADMIN', 'COMMERCIAL'])`.

| Route | Page | Data Functions |
|-------|------|----------------|
| `/{locale}/admin` | Admin Dashboard | `getAdminStats()` |
| `/{locale}/admin/partners` | Partner List | `getAdminPartners({page, search, status})` |
| `/{locale}/admin/cases` | Case List | `getAdminCases({page, search, status, partnerId})` |
| `/{locale}/admin/cases/new` | New Case | `getPartnerOptions()` |
| `/{locale}/admin/events` | Event List | `getAdminEvents({page, search})` |
| `/{locale}/admin/academy` | Content List | `getAdminAcademyContent({page, search, type})` |
| `/{locale}/admin/documents` | Document List | `getAdminDocuments({page, search, category})` |
| `/{locale}/admin/blog` | Blog List | `getAdminBlogPosts({page, search})` |
| `/{locale}/admin/access-requests` | Access Requests | `getAccessRequests({status, page})` |

---

## Layout Components

### Locale Layout (`[locale]/layout.tsx`)
- Wraps app in `NextIntlClientProvider` with locale messages
- Sets `data-theme` attribute from cookie (persisted theme preference)
- Generates locale-aware metadata

### Dashboard Layout (`(dashboard)/layout.tsx`)
```
┌─────────────────────────────────────────────┐
│              Header (64px)                   │
│  Logo | [search?] | Bell (notifs) | Avatar   │
├──────────┬──────────────────────────────────┤
│ Sidebar  │  Main Content ({children})        │
│ (240px)  │  (scrollable)                     │
│          │                                   │
│ Dashboard│                                   │
│ Cases    │                                   │
│ Events   │                                   │
│ Academy  │                                   │
│ Docs     │                                   │
│ Blog     │                                   │
│ Community│                                   │
│ ──────   │                                   │
│ Activity │                                   │
│ Profile  │                                   │
│ Settings │                                   │
│ ──────   │                                   │
│ Admin ↗  │  (ADMIN/COMMERCIAL only)          │
│ ──────   │                                   │
│ Sign out │                                   │
├──────────┴──────────────────────────────────┤
│  Bottom Nav (mobile only, 60px)              │
│  Dashboard | Cases | Events | Academy | More │
└─────────────────────────────────────────────┘
```

### Admin Layout (`(admin)/admin/layout.tsx`)
Server Component. Calls `requireRole(['ADMIN', 'COMMERCIAL'])` before rendering.
```
┌─────────────────────────────────────────────┐
│ Admin Header                                 │
│ "Admin Panel" | ← Back to Dashboard | Avatar │
├──────────┬──────────────────────────────────┤
│ Admin    │  Main Content ({children})        │
│ Sidebar  │                                   │
│          │                                   │
│ Dashboard│                                   │
│ Partners │                                   │
│ Cases    │                                   │
│ Events   │                                   │
│ Academy  │                                   │
│ Docs     │                                   │
│ Blog     │                                   │
│ Requests │                                   │
└──────────┴──────────────────────────────────┘
```

---

## Loading & Error Boundaries

Every route segment that fetches data has:

### `loading.tsx`
```typescript
// Imports PageSkeleton component
import { ListPageSkeleton } from '@/components/ui/PageSkeleton';
export default function Loading() { return <ListPageSkeleton />; }
```
Renders instantly while the Server Component fetches data (Next.js Suspense).

### `error.tsx`
```typescript
'use client'
import { ErrorDisplay } from '@/components/ui/ErrorDisplay';
export default function Error({ error, reset }: { error: Error; reset: () => void }) {
  return <ErrorDisplay error={error} onRetry={reset} />;
}
```

---

## Middleware Route Matching

`src/middleware.ts` runs on every request matched by:

```typescript
export const config = {
  matcher: ['/((?!api|_next|_vercel|.*\\..*).*)'],
};
```

This matches all routes EXCEPT:
- `/_next/*` — Next.js internals
- `/_vercel/*` — Vercel internals
- Any path with a file extension (static assets)

The middleware:
1. Runs next-intl locale detection/prefix handling
2. Calls `supabase.auth.getUser()` on protected paths
3. Redirects to `/{locale}/login` if no valid session on dashboard/admin routes
4. Redirects to `/{locale}/admin` if ADMIN/COMMERCIAL user tries to access dashboard (optional)

> **Rule**: Always use `getUser()` in middleware, never `getSession()`. `getSession()` reads from the cookie without server-side validation and can be spoofed.

---

## Navigation — Locale-Aware

Always import from `src/navigation.ts`, never from Next.js directly:

```typescript
// ✅ Correct
import { Link, redirect, useRouter, usePathname } from '@/navigation';

// ❌ Wrong
import Link from 'next/link';
import { redirect } from 'next/navigation';
```

`src/navigation.ts` wraps Next.js navigation with locale awareness so links automatically include the current locale prefix.
