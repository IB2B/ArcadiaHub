# Project Structure

Single Next.js application — no monorepo, no separate backend.

```
ArcadiaHub/
├── messages/                        # i18n translations
│   ├── en.json                      # English (default, most complete)
│   ├── it.json                      # Italian (partial — finish in Week 4)
│   └── fr.json                      # French  (partial — finish in Week 4)
│
├── supabase/
│   └── migrations/
│       ├── 001_initial_schema.sql
│       ├── 002_access_requests.sql
│       ├── 003_fix_rls_recursion.sql   # ← renamed from 002_ (Bug 13 fix)
│       ├── 003_schema_fixes_and_performance.sql
│       └── 004_missing_tables.sql      # ← must create (Bugs 1, 2, 4, 5, 6)
│
├── docs/
│   ├── arcadia-hub-project-plan.tex   # Technical rebuild plan (LaTeX)
│   └── simple-project-plan.tex        # PM-facing plan (LaTeX)
│
├── plan/                              # This directory — implementation notes
│
├── src/
│   ├── app/
│   │   └── [locale]/
│   │       ├── layout.tsx
│   │       ├── page.tsx               # Landing page
│   │       ├── not-found.tsx
│   │       │
│   │       ├── (auth)/                # Public — no session required
│   │       │   ├── login/
│   │       │   ├── forgot-password/
│   │       │   ├── reset-password/
│   │       │   └── request-access/
│   │       │
│   │       ├── (dashboard)/           # Protected — requires session
│   │       │   ├── layout.tsx         # AppShell (Sidebar + Header + BottomNav)
│   │       │   ├── dashboard/
│   │       │   ├── cases/
│   │       │   │   └── [id]/
│   │       │   ├── events/
│   │       │   │   └── [id]/
│   │       │   ├── academy/
│   │       │   │   └── [id]/
│   │       │   ├── documents/
│   │       │   │   └── [id]/
│   │       │   ├── blog/
│   │       │   │   └── [slug]/
│   │       │   ├── community/
│   │       │   │   └── [id]/
│   │       │   ├── notifications/     # ⚠️ page.tsx missing — Bug 9
│   │       │   ├── activity/
│   │       │   ├── profile/
│   │       │   └── settings/
│   │       │
│   │       └── (admin)/               # Protected — requires ADMIN or COMMERCIAL
│   │           └── admin/
│   │               ├── layout.tsx     # Admin shell (server-side role gate)
│   │               ├── partners/
│   │               ├── cases/
│   │               ├── events/
│   │               ├── academy/
│   │               ├── documents/
│   │               ├── blog/
│   │               └── access-requests/
│   │
│   ├── components/
│   │   ├── ui/                        # Custom primitives — no shadcn/Radix
│   │   │   ├── Button.tsx
│   │   │   ├── Card.tsx
│   │   │   ├── Input.tsx
│   │   │   ├── Select.tsx
│   │   │   ├── Modal.tsx
│   │   │   ├── Badge.tsx
│   │   │   ├── Table.tsx
│   │   │   ├── Tabs.tsx
│   │   │   ├── Toggle.tsx
│   │   │   ├── Textarea.tsx
│   │   │   ├── Pagination.tsx
│   │   │   ├── Avatar.tsx
│   │   │   ├── FileUpload.tsx
│   │   │   ├── ErrorDisplay.tsx
│   │   │   └── PageSkeleton.tsx
│   │   │
│   │   ├── layout/
│   │   │   ├── Sidebar.tsx
│   │   │   ├── Header.tsx
│   │   │   ├── BottomNav.tsx          # Mobile navigation
│   │   │   ├── LanguageSwitcher.tsx
│   │   │   └── SessionTimeout.tsx
│   │   │
│   │   ├── cases/
│   │   │   ├── CaseCard.tsx
│   │   │   ├── CaseFilters.tsx        # ⚠️ uses hardcoded hex — Bug 11
│   │   │   └── CaseTimeline.tsx
│   │   │
│   │   ├── events/
│   │   │   ├── EventCard.tsx
│   │   │   └── CalendarView.tsx
│   │   │
│   │   ├── comments/                  # To be created in Week 3
│   │   │   ├── CommentSection.tsx
│   │   │   ├── CommentItem.tsx
│   │   │   └── MentionInput.tsx
│   │   │
│   │   ├── dashboard/
│   │   │   ├── StatsCard.tsx
│   │   │   ├── TimelineFeed.tsx
│   │   │   └── SuggestionModal.tsx    # To be created in Week 3
│   │   │
│   │   ├── community/
│   │   │   └── PartnerCard.tsx
│   │   │
│   │   ├── documents/
│   │   │   └── DocumentPreview.tsx
│   │   │
│   │   └── landing/
│   │       └── (landing page sections)
│   │
│   ├── lib/
│   │   ├── database/
│   │   │   ├── client.ts              # createBrowserClient — Client Components only
│   │   │   └── server.ts              # createClient() + createServiceSupabaseClient()
│   │   │
│   │   ├── auth/
│   │   │   ├── actions.ts             # login, logout, password reset, access request
│   │   │   ├── guards.ts              # requireAuth(), requireRole()
│   │   │   └── index.ts               # re-exports
│   │   │
│   │   ├── data/                      # Server Actions — one file per domain
│   │   │   ├── cases.ts
│   │   │   ├── events.ts
│   │   │   ├── academy.ts
│   │   │   ├── documents.ts
│   │   │   ├── blog.ts
│   │   │   ├── profiles.ts
│   │   │   ├── notifications.ts
│   │   │   ├── accessRequests.ts      # ⚠️ inline role check — Bug 7 fix needed
│   │   │   ├── dashboard.ts           # ⚠️ N+1 feed queries — Bug 6 fix needed
│   │   │   ├── admin.ts               # ⚠️ inline role check — Bug 14 fix needed
│   │   │   ├── suggestions.ts         # To be created in Week 3
│   │   │   └── comments.ts            # To be created in Week 3
│   │   │
│   │   ├── email/
│   │   │   ├── client.ts              # Resend SDK init
│   │   │   ├── config.ts              # FROM_EMAIL, app name
│   │   │   ├── send.ts                # sendEmail() wrapper
│   │   │   ├── index.ts               # Named send functions
│   │   │   └── templates/
│   │   │       ├── base.ts            # ✅ exists
│   │   │       ├── partner-welcome.ts  # ✅ exists — wired to approveAccessRequest
│   │   │       ├── password-reset.ts   # ✅ exists
│   │   │       ├── notification.ts     # ✅ exists
│   │   │       ├── access-request-received.ts   # To create Week 3
│   │   │       ├── access-request-rejection.ts  # To create Week 3
│   │   │       ├── case-status-update.ts         # To create Week 3
│   │   │       ├── case-document-added.ts        # To create Week 3
│   │   │       ├── event-published.ts            # To create Week 3
│   │   │       ├── user-invite.ts                # To create Week 3
│   │   │       ├── suggestion-received.ts        # To create Week 3
│   │   │       └── comment-mention.ts            # To create Week 3
│   │   │
│   │   ├── services/
│   │   │   ├── notificationService.ts  # Uses service role client — inserts notifications
│   │   │   └── storage.ts              # Supabase Storage helpers
│   │   │
│   │   ├── validators/
│   │   │   └── index.ts               # All Zod schemas
│   │   │
│   │   └── logger.ts                  # Structured logging helper
│   │
│   ├── hooks/
│   │   ├── useNotifications.ts        # ⚠️ uses 30s polling — replace with Realtime (Bug 10)
│   │   └── useTheme.ts
│   │
│   ├── types/
│   │   └── database.types.ts          # Auto-generated by Supabase CLI
│   │
│   ├── i18n.ts                        # next-intl config (locales: en, it, fr)
│   ├── navigation.ts                  # Locale-aware Link, redirect, useRouter
│   └── middleware.ts                  # Auth guard + i18n routing
│
├── CLAUDE.md                          # Project instructions for Claude Code
├── TASKS.md                           # Outstanding feature task list (76 tasks)
├── next.config.ts
├── tsconfig.json
└── package.json
```

---

## Critical Rules (from CLAUDE.md)

- **No API routes** — use Server Actions in `src/lib/data/` for all mutations
- **Locale-aware navigation** — always import `Link`, `redirect`, `useRouter` from `src/navigation.ts`, never from Next.js directly
- **Two Supabase clients** — `createClient()` for normal use, `createServiceSupabaseClient()` only in `notificationService.ts` and `accessRequests.ts`
- **CSS variables only** — all colors via `var(--primary)` etc., never hardcode hex values
- **Custom UI only** — no shadcn/ui, no Radix UI
- **Server Components by default** — only add `'use client'` for interactive components
- **Always `revalidatePath()`** after mutations
- **Always validate with Zod** before touching the database
- **Keep i18n in sync** — add new strings to en.json, it.json, and fr.json simultaneously
