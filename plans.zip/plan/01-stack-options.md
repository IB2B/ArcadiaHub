# Stack — Next.js + Supabase

ArcadiaHub uses a **full-stack Next.js** architecture backed by Supabase. There is no separate backend service.

---

## Architecture

```
┌─────────────────────────────────────────────────────┐
│                    Browser                          │
│  React Client Components (interactive UI)           │
│  Supabase Realtime (WebSocket for notifications)    │
└──────────────┬──────────────────────────────────────┘
               │  Server Actions / Page requests
┌──────────────▼──────────────────────────────────────┐
│              Next.js 16 (Vercel)                    │
│  Server Components  — SSR pages                     │
│  Server Actions     — all mutations (no REST API)   │
│  Middleware         — auth guard + i18n routing     │
└──────────────┬──────────────────────────────────────┘
               │  Supabase SDK (server-side)
┌──────────────▼──────────────────────────────────────┐
│                  Supabase (managed)                 │
│  ┌───────────┐  ┌──────────┐  ┌──────────────────┐ │
│  │ PostgreSQL│  │ GoTrue   │  │ Storage Buckets  │ │
│  │ + RLS     │  │ (Auth)   │  │ (files/uploads)  │ │
│  └───────────┘  └──────────┘  └──────────────────┘ │
│  ┌───────────────────────────┐                      │
│  │ Realtime (WebSocket pub)  │                      │
│  └───────────────────────────┘                      │
└─────────────────────────────────────────────────────┘
               │
┌──────────────▼──────────────────────────────────────┐
│               Resend (email API)                    │
└─────────────────────────────────────────────────────┘
```

---

## Tech Stack

| Layer | Technology | Version | Purpose |
|-------|-----------|---------|---------|
| Framework | Next.js (App Router) | 16.0.7 | SSR, routing, Server Actions, middleware |
| UI | React | 19.2.0 | Server + Client Components |
| Language | TypeScript | 5 (strict) | Type safety throughout |
| Styling | Tailwind CSS | v4 | CSS-first config, CSS variables for theming |
| Database / Auth | Supabase | managed | PostgreSQL, GoTrue auth, Storage, Realtime |
| i18n | next-intl | 4.5.6 | 3-locale support (en/it/fr) |
| Email | Resend | 6.5.2 | Transactional email |
| Validation | Zod | 4.1.13 | Schema-first input validation |
| Deployment | Vercel | — | Edge network, zero-config Next.js |

---

## Why Not Spring Boot

The original plan described a Spring Boot backend. We are not doing that.

| Concern | Spring Boot + Next.js | Next.js + Supabase (chosen) |
|---------|----------------------|------------------------------|
| Authentication | Custom JWT + key rotation | GoTrue, fully managed by Supabase |
| Authorization | Manual checks in controllers | Row Level Security enforced at DB level |
| File storage | S3/MinIO + streaming endpoint | Supabase Storage with built-in CDN |
| Real-time | WebSocket server to build and host | Supabase Realtime, one subscription call |
| Deployment | Two separate codebases and deploys | Single Vercel project + Supabase project |
| Type safety | OpenAPI spec to bridge Java ↔ TypeScript | Supabase CLI generates TypeScript types from schema |
| Infrastructure cost | JVM always-on server + DB instance | Serverless (Vercel) + Supabase free tier |
| Time to market | ~2× longer | Fastest path |

---

## Two Supabase Clients

```typescript
// src/lib/database/server.ts

// Standard client — respects Row Level Security
// Use this everywhere except where noted below
export async function createClient() { ... }

// Service role client — bypasses RLS
// Only used in:
//   - notificationService.ts (insert notifications for any user)
//   - accessRequests.ts (call supabase.auth.admin to create users on approval)
export function createServiceSupabaseClient() { ... }
```

> **Rule**: Never import `createServiceSupabaseClient` in a data file unless you need `auth.admin` or must insert rows for other users. All other server actions use `createClient()`.

---

## Server Action Pattern

Every mutation follows this shape:

```typescript
'use server';

import { createClient } from '@/lib/database/server';
import { requireRole } from '@/lib/auth/guards';
import { revalidatePath } from 'next/cache';
import { z } from 'zod/v4';

const Schema = z.object({
  title: z.string().min(1).max(200),
});

export async function createSomething(data: unknown) {
  // 1. Validate input
  const parsed = Schema.safeParse(data);
  if (!parsed.success)
    return { success: false, error: parsed.error.issues[0]?.message };

  // 2. Check auth + role (throws if unauthorized)
  await requireRole(['ADMIN', 'COMMERCIAL']);

  // 3. Query database via RLS-respecting client
  const supabase = await createClient();
  const { data: result, error } = await supabase
    .from('table_name')
    .insert(parsed.data)
    .select()
    .single();

  if (error) return { success: false, error: error.message };

  // 4. Invalidate Next.js page cache
  revalidatePath('/[locale]/relevant-path');
  return { success: true, data: result };
}
```

---

## Data Flow

### Read (e.g., partner views their cases)
```
1. Browser requests /it/cases
2. Next.js middleware checks Supabase session cookie → authenticated ✓
3. CasesPage (Server Component) calls getMyCases() Server Action
4. getMyCases() calls createClient() → executes SELECT on 'cases'
5. RLS policy: WHERE partner_id = auth.uid() — Supabase enforces this at DB level
6. Server Component renders HTML and streams to browser
```

### Write (e.g., partner creates a case)
```
1. Browser submits form → CasesPageClient calls createCase() Server Action
2. createCase() validates input with Zod
3. requireAuth() verifies session via getUser() (not getSession — avoids spoofing)
4. Inserts row using createClient() (RLS ensures partner_id = auth.uid())
5. revalidatePath('/[locale]/cases') invalidates the cases page cache
6. Returns { success: true, data: newCase }
7. Client component shows success state and router refreshes
```

---

## Storage Buckets

| Bucket | Access | Contents |
|--------|--------|----------|
| `avatars` | Public | Partner profile photos |
| `case-documents` | Private (signed URL) | Documents attached to cases |
| `academy-content` | Private (signed URL) | Videos and PDFs for academy items |
| `documents` | Private (signed URL) | Technical documents for partners |
| `blog-images` | Public | Cover images for blog posts |
| `event-images` | Public | Cover images for events |

---

## Environment Variables

```bash
# Public (safe for browser)
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
NEXT_PUBLIC_APP_URL=
NEXT_PUBLIC_APP_NAME=

# Server-only — NEVER put in NEXT_PUBLIC_* variables
SUPABASE_SERVICE_ROLE_KEY=
SUPABASE_PROJECT_ID=
RESEND_API_KEY=
FROM_EMAIL=
ADMIN_NOTIFICATION_EMAIL=      # Jiani's address for admin alerts
PARTNER_BULK_EMAIL_ENABLED=    # true/false — controls event blast emails
```

---

## Local Development

```bash
# Install dependencies
npm install

# Start dev server (Next.js + Supabase local or cloud project)
npm run dev

# Lint
npm run lint

# Build
npm run build

# Seed database
npm run seed
```
