# Business Logic — Complete Reference

All business rules, workflows, state machines, and domain logic in ArcadiaHub. All logic runs in Next.js Server Actions (`src/lib/data/`) — there is no separate backend service.

---

## 1. Case Lifecycle

### State Machine
```
                  ┌─────────────┐
                  │   PENDING   │ ← initial state on creation
                  └──────┬──────┘
                         │ Admin starts work
                         ▼
                  ┌─────────────┐
            ┌─────│ IN_PROGRESS │─────┐
            │     └──────┬──────┘     │
            │ Suspended  │ Resolved   │ Cancelled
            ▼            ▼            ▼
     ┌───────────┐ ┌───────────┐ ┌───────────┐
     │ SUSPENDED │ │ COMPLETED │ │ CANCELLED │
     └─────┬─────┘ └───────────┘ └───────────┘
           │ Resumed
           ▼
     ┌─────────────┐
     │ IN_PROGRESS │
     └─────────────┘
```

### Case Status Values
| Status | Description | Badge Color |
|--------|-------------|-------------|
| `PENDING` | New case, awaiting assignment | Warning (amber) |
| `IN_PROGRESS` | Actively being worked on | Info (blue) |
| `SUSPENDED` | Temporarily paused | Gray |
| `COMPLETED` | Successfully resolved | Success (green) |
| `CANCELLED` | Closed without resolution | Error (red) |

### Case Code Generation
Auto-generated on creation via PostgreSQL sequence — **not Math.random()** (Bug 4 fix):
```sql
-- Sequence defined in Migration 004
CREATE SEQUENCE IF NOT EXISTS case_code_seq;

CREATE OR REPLACE FUNCTION next_case_code() RETURNS TEXT AS $$
  SELECT TO_CHAR(NOW(), 'YYYY') || '-' || LPAD(nextval('case_code_seq')::TEXT, 4, '0');
$$ LANGUAGE SQL;
-- Returns: '2025-0042'
```

Application code calls `supabase.rpc('next_case_code')` — never constructs codes manually.

### Case History (Audit Log)
Every status change is logged **exclusively by the DB trigger** `log_case_status_change()`:

```sql
CREATE FUNCTION log_case_status_change() RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO case_history (case_id, old_status, new_status, changed_by)
  VALUES (NEW.id, OLD.status, NEW.status, auth.uid());
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER on_case_status_change
AFTER UPDATE ON cases
WHEN (OLD.status IS DISTINCT FROM NEW.status)
FOR EACH ROW EXECUTE FUNCTION log_case_status_change();
```

> ⚠️ **Bug 3**: `admin.ts updateCase()` previously inserted a row into `case_history` manually in addition to the trigger, causing duplicate history entries. Fix: remove the manual insert — the trigger handles it exclusively.

### Access Rules
- **PARTNER**: Can only view/create own cases (enforced by RLS: `partner_id = auth.uid()`)
- **COMMERCIAL**: Can view all cases (no RLS restriction for this role)
- **ADMIN**: Can view/edit all cases

---

## 2. Access Request → Partner Onboarding

### Application Form Fields
```
Required:
  - first_name, last_name
  - email
  - company_name

Optional:
  - message (motivation text)
```

### Approval Flow
```
1. Visitor submits form at /{locale}/request-access
   → submitAccessRequest() validates with AccessRequestSchema (Zod)
   → INSERT into access_requests (status = 'pending')
   → sendAccessRequestReceivedEmail(applicant_email)  ← must wire (Week 3)
   → sendAdminAlertEmail(ADMIN_NOTIFICATION_EMAIL)    ← must wire (Week 3)
   → notifyAccessRequestSubmitted() for all ADMIN users

2. Admin reviews in /admin/access-requests

3a. approveAccessRequest(id):
    → requireRole(['ADMIN', 'COMMERCIAL'])
    → supabase.auth.admin.createUser({ email, email_confirm: true })
       [uses createServiceSupabaseClient() — only valid use case in accessRequests.ts]
    → upsert profile with role = 'PARTNER'
    → sendPartnerWelcomeEmail()  ← ✅ already wired
    → UPDATE access_requests SET status = 'approved'
    → revalidatePath('/[locale]/(admin)/admin/access-requests')

3b. rejectAccessRequest(id, notes):
    → requireRole(['ADMIN', 'COMMERCIAL'])
    → UPDATE access_requests SET status = 'rejected', review_notes = notes
    → sendAccessRequestRejectionEmail()  ← must wire (Week 3)
    → revalidatePath('/[locale]/(admin)/admin/access-requests')
```

---

## 3. Event Registration

### Registration Flow
```typescript
// src/lib/data/events.ts
export async function registerForEvent(eventId: string) {
  await requireAuth();
  const supabase = await createServerSupabaseClient();

  // Check event exists, is published, and is in the future
  // Check capacity not exceeded
  // Check not already registered (UNIQUE constraint handles this too)
  // INSERT into event_registrations

  revalidatePath('/[locale]/(dashboard)/events');
}
```

Capacity enforcement:
```sql
-- Check current registration count vs capacity
SELECT COUNT(*) FROM event_registrations WHERE event_id = $1;
-- If count >= events.capacity AND capacity IS NOT NULL → reject
```

Duplicate prevention: `UNIQUE (event_id, user_id)` constraint in `event_registrations` table (created in Migration 004).

### Event Types
| Type | Description |
|------|-------------|
| `webinar` | Online webinar |
| `training` | In-person training session |
| `conference` | Conference or summit |

---

## 4. Academy / Learning Progress

### Progress Tracking
```typescript
// src/lib/data/academy.ts
export async function markContentComplete(contentId: string) {
  await requireAuth();
  const supabase = await createServerSupabaseClient();

  // UPSERT into content_completions (content_id, user_id)
  // UNIQUE (content_id, user_id) prevents duplicates

  revalidatePath('/[locale]/(dashboard)/academy');
}
```

### View Count (Atomic)
```typescript
// Use RPC — never read-then-write (Bug 5 fix)
await supabase.rpc('increment_view', { tbl: 'academy_content', row_id: id });
```

```sql
CREATE OR REPLACE FUNCTION increment_view(tbl TEXT, row_id UUID) RETURNS VOID AS $$
BEGIN
  EXECUTE FORMAT('UPDATE %I SET view_count = view_count + 1 WHERE id = $1', tbl) USING row_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
```

---

## 5. Document Management

### Access Rules
- Published documents visible to all authenticated users (RLS: `is_published = true`)
- Only ADMIN/COMMERCIAL can create/update/delete documents
- Download count incremented via the same `increment_view()` RPC pattern

---

## 6. Blog System

### View Counting
Same atomic RPC as academy:
```typescript
await supabase.rpc('increment_view', { tbl: 'blog_posts', row_id: id });
```

### Slug Generation (application-level)
```typescript
function generateSlug(title: string): string {
  return title
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, '')
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-')
    .trim();
}
// "How to Optimize Your Partnership" → "how-to-optimize-your-partnership"
```

Uniqueness enforced by `slug TEXT NOT NULL UNIQUE` in DB.

---

## 7. Notification System

### Creation — Server-Side Only
Notifications are created by `src/lib/services/notificationService.ts` using `createServiceSupabaseClient()` (bypasses RLS so it can INSERT for any user_id):

```typescript
// notificationService.ts
export async function notifyCaseStatusChanged(caseId: string, partnerId: string, newStatus: string) {
  const supabase = createServiceSupabaseClient();
  await supabase.from('notifications').insert({
    user_id: partnerId,
    type: 'case_status_changed',
    title: 'Case Status Changed',
    message: `Your case status changed to ${newStatus}`,
    link: `/cases/${caseId}`,
  });
}
```

### Delivery — Supabase Realtime
```typescript
// src/hooks/useNotifications.ts
// Replace the current 30s polling (Bug 10 fix) with Realtime subscription:
const channel = supabase
  .channel('notifications')
  .on('postgres_changes', {
    event: 'INSERT',
    schema: 'public',
    table: 'notifications',
    filter: `user_id=eq.${userId}`,
  }, (payload) => {
    // Update notification list and unread count
  })
  .subscribe();
```

### Notification Types
| Type | Trigger | Recipients |
|------|---------|------------|
| `case_created` | New case created | Assigned partner |
| `case_status_changed` | Case status update | Case partner |
| `case_document_added` | Doc added to case | Case partner |
| `event_published` | Event goes live | All partners |
| `event_registration` | Partner registers | (confirmation) |
| `academy_content_published` | New content | All partners |
| `document_published` | New document | All partners |
| `blog_post_published` | New blog post | All partners |
| `access_request_submitted` | New access request | All ADMIN users |
| `access_request_approved` | Request approved | Applicant |
| `access_request_rejected` | Request rejected | Applicant |
| `mention` | @mention in comment | Mentioned user |
| `suggestion_reply` | Admin replied | Suggestion author |

---

## 8. Role Guards Pattern

Every Server Action that writes data must call `requireAuth()` or `requireRole()` at the top:

```typescript
// src/lib/auth/guards.ts
export async function requireAuth(): Promise<{ userId: string; profile: Profile }>
export async function requireRole(roles: string[]): Promise<{ userId: string; profile: Profile }>
```

Usage:
```typescript
// ✅ Correct
import { requireRole } from '@/lib/auth/guards';

export async function deletePartner(id: string) {
  await requireRole(['ADMIN', 'COMMERCIAL']);
  // ...
}

// ❌ Wrong — inline check (Bug 7 / Bug 14 pattern to fix)
const profile = await getCurrentProfile();
if (!profile || !['ADMIN', 'COMMERCIAL'].includes(profile.role)) {
  throw new Error('Unauthorized');
}
```

> **Bug 7**: `accessRequests.ts` uses inline check — must refactor to `requireRole()`
> **Bug 14**: `admin.ts` has its own `requireAdminOrCommercial()` — must replace with shared `requireRole()`

---

## 9. Email Wiring

All email functions exist in `src/lib/email/` but many are not yet called from Server Actions. Wiring status:

| Trigger | Email Function | Status |
|---------|---------------|--------|
| Access request approved | `sendPartnerWelcomeEmail()` | ✅ Wired |
| Forgot password | `supabase.auth.resetPasswordForEmail()` | ✅ Wired |
| Access request submitted | `sendAccessRequestReceivedEmail()` | ⚠️ Not wired |
| Admin alert on access request | `sendAdminAlertEmail()` | ⚠️ Not wired |
| Access request rejected | `sendAccessRequestRejectionEmail()` | ⚠️ Not wired |
| Case status changed | `sendCaseStatusUpdateEmail()` | ⚠️ Not wired |
| Event published (blast) | `sendEventPublishedEmail()` | ⚠️ Not wired |
| Sub-user created | `sendUserInviteEmail()` | ⚠️ Not wired |

All 6 unwired flows are Phase 3 tasks.

---

## 10. Activity Feed (Dashboard)

Current implementation fetches 5 separate queries and sorts client-side (Bug 6 — N+1 pattern).

Correct implementation: single `UNION ALL` view in PostgreSQL:

```sql
-- src/lib/data/dashboard.ts should call this view
CREATE OR REPLACE VIEW activity_feed AS
  SELECT id, 'case_created'::TEXT AS type, created_at, partner_id AS user_id FROM cases
  UNION ALL
  SELECT id, 'event_published'::TEXT, created_at, NULL FROM events WHERE is_published = true
  UNION ALL
  SELECT id, 'document_published'::TEXT, created_at, NULL FROM documents WHERE is_published = true
  UNION ALL
  SELECT id, 'blog_post_published'::TEXT, created_at, NULL FROM blog_posts WHERE is_published = true
  UNION ALL
  SELECT id, 'academy_content_published'::TEXT, created_at, NULL FROM academy_content WHERE is_published = true
  ORDER BY created_at DESC
  LIMIT 50;
```

---

## 11. Search & Filtering Patterns

### Text Search (ILIKE)
```typescript
// In Server Actions
if (search) {
  query = query.ilike('title', `%${search}%`);
}
```

### Pagination
```typescript
const from = (page - 1) * pageSize;
const to = from + pageSize - 1;
query = query.range(from, to);

// Count for totalPages
const { count } = await supabase
  .from('table')
  .select('*', { count: 'exact', head: true });
```

### Default Sort
- Most tables: `.order('created_at', { ascending: false })`
- Events: `.order('event_date', { ascending: true })` for upcoming
- Partners (community): `.order('company_name', { ascending: true })`

---

## 12. File Storage (Supabase Storage)

### Buckets
| Bucket | Access | Purpose |
|--------|--------|---------|
| `avatars` | Public read | Partner logos |
| `case-documents` | Signed URLs | Case file attachments |
| `academy-content` | Signed URLs | Academy media |
| `documents` | Signed URLs | Platform documents |
| `blog-images` | Public read | Blog cover images |
| `event-images` | Public read | Event cover images |

### Upload Pattern
```typescript
// src/lib/services/storage.ts
export async function uploadFile(file: File, bucket: string, path: string): Promise<string> {
  const supabase = await createServerSupabaseClient();
  const { data, error } = await supabase.storage
    .from(bucket)
    .upload(path, file, { upsert: true });

  if (error) throw new Error(error.message);

  const { data: { publicUrl } } = supabase.storage
    .from(bucket)
    .getPublicUrl(data.path);

  return publicUrl;
}
```

### File Validation
```
Partner logos:
  - Types: image/jpeg, image/png, image/webp
  - Max size: 5MB

Case documents:
  - Types: any (PDF, images, office docs)
  - Max size: 10MB
```

---

## 13. revalidatePath Rules

After every mutation, call `revalidatePath()` to refresh server-rendered data:

| Mutation | revalidatePath() call |
|----------|-----------------------|
| Create/update case | `revalidatePath('/[locale]/(dashboard)/cases')` |
| Update case status | `revalidatePath('/[locale]/(dashboard)/cases')` |
| Create/update event | `revalidatePath('/[locale]/(dashboard)/events')` |
| Publish blog post | `revalidatePath('/[locale]/(dashboard)/blog')` |
| Publish document | `revalidatePath('/[locale]/(dashboard)/documents')` |
| Approve/reject access request | `revalidatePath('/[locale]/(admin)/admin/access-requests')` |
| Update profile | `revalidatePath('/[locale]/(dashboard)/profile')` |

> **Bug 12**: `events.ts createEvent()` is missing `revalidatePath()` — add it.

---

## 14. Seed Data

```typescript
// scripts/seed.ts (npm run seed)
// Creates:
// - admin@harlock.it (ADMIN role)
// - commercial@harlock.it (COMMERCIAL role)
// - partner@demo.it (PARTNER role)
// - 5+ partner profiles with Italian company data
// - 10+ cases across statuses
// - 5+ events (past + upcoming)
// - 5+ academy content items
// - 5+ documents
// - 3+ blog posts
// - 3 access requests (pending / approved / rejected)
// - 20+ notifications

// Dev password for all seeded users: Password123!
```
