# Internationalization & Configuration — Complete Reference

All i18n setup, translation structure, locale management, and application configuration.

---

## Internationalization Architecture

### Supported Locales
| Code | Language | Status |
|------|----------|--------|
| `en` | English | Default — most complete |
| `it` | Italian | Partial — finish Week 4 |
| `fr` | French | Partial — finish Week 4 |

### Default Locale
`en` (English). All new strings must be added to all 3 files simultaneously.

### URL Strategy
`localePrefix: 'always'` — every URL includes the locale prefix:
```
/en/dashboard
/it/dashboard
/fr/dashboard
```

### Technology
- **Library**: `next-intl` v4.5.6
- **Server rendering**: `getTranslations()` in Server Components
- **Client rendering**: `useTranslations()` in Client Components; `NextIntlClientProvider` wraps the locale layout

---

## Configuration Files

### `src/i18n.ts`
```typescript
import { getRequestConfig } from 'next-intl/server';

export default getRequestConfig(async ({ requestLocale }) => {
  let locale = await requestLocale;
  if (!locale || !['en', 'it', 'fr'].includes(locale)) {
    locale = 'en';
  }
  return {
    locale,
    messages: (await import(`../messages/${locale}.json`)).default,
  };
});
```

### `src/navigation.ts`
```typescript
import { createNavigation } from 'next-intl/navigation';

export const locales = ['en', 'it', 'fr'] as const;
export type Locale = (typeof locales)[number];

export const { Link, redirect, usePathname, useRouter, getPathname } =
  createNavigation({
    locales,
    localePrefix: 'always',
  });
```

### `next.config.ts`
```typescript
import createNextIntlPlugin from 'next-intl/plugin';

const withNextIntl = createNextIntlPlugin('./src/i18n.ts');

const nextConfig: NextConfig = {
  // image domains, etc.
};

export default withNextIntl(nextConfig);
```

---

## Translation File Structure

Each locale has one file: `messages/{locale}.json`

### Top-Level Sections
```json
{
  "common": { },       // Shared labels, buttons, status names
  "landing": { },      // Landing/marketing page
  "auth": { },         // Login, forgot-password, reset-password, request-access
  "dashboard": { },    // Dashboard page
  "cases": { },        // Cases module
  "events": { },       // Events module
  "academy": { },      // Academy module
  "documents": { },    // Documents module
  "blog": { },         // Blog module
  "community": { },    // Community / partner directory
  "notifications": { },// Notifications page
  "profile": { },      // Profile page
  "settings": { },     // Settings page
  "admin": { },        // Admin panel (all sections)
  "activity": { },     // Activity feed
  "requestAccess": { },// Access request form
  "errors": { },       // Error messages
  "navigation": { }    // Nav labels, sidebar, bottom nav
}
```

### Common Section
```json
{
  "common": {
    "loading": "Loading...",
    "save": "Save",
    "cancel": "Cancel",
    "delete": "Delete",
    "edit": "Edit",
    "create": "Create",
    "search": "Search",
    "filter": "Filter",
    "all": "All",
    "back": "Back",
    "next": "Next",
    "previous": "Previous",
    "confirm": "Confirm",
    "close": "Close",
    "noResults": "No results found",
    "required": "Required",
    "optional": "Optional",
    "roles": {
      "ADMIN": "Administrator",
      "COMMERCIAL": "Commercial",
      "PARTNER": "Partner"
    },
    "caseStatus": {
      "PENDING": "Pending",
      "IN_PROGRESS": "In Progress",
      "COMPLETED": "Completed",
      "CANCELLED": "Cancelled",
      "SUSPENDED": "Suspended"
    },
    "eventTypes": {
      "webinar": "Webinar",
      "training": "Training",
      "conference": "Conference"
    }
  }
}
```

### Module-Specific Pattern
```json
{
  "cases": {
    "title": "My Cases",
    "subtitle": "Track and manage your support cases",
    "newCase": "New Case",
    "caseCode": "Case Code",
    "clientName": "Client Name",
    "status": "Status",
    "noCases": "No cases found",
    "filters": {
      "all": "All Cases",
      "pending": "Pending",
      "inProgress": "In Progress",
      "completed": "Completed"
    },
    "detail": {
      "timeline": "Case Timeline",
      "documents": "Documents",
      "statusChange": "Status changed from {from} to {to}",
      "noDocuments": "No documents attached"
    }
  }
}
```

### Admin Section (Nested)
```json
{
  "admin": {
    "title": "Admin Panel",
    "dashboard": {
      "title": "Dashboard",
      "totalPartners": "Total Partners",
      "activePartners": "Active Partners",
      "totalCases": "Total Cases",
      "pendingCases": "Pending Cases",
      "upcomingEvents": "Upcoming Events",
      "pendingRequests": "Pending Requests"
    },
    "partners": {
      "title": "Partners",
      "addPartner": "Add Partner",
      "editPartner": "Edit Partner",
      "companyName": "Company Name",
      "status": "Status",
      "active": "Active",
      "inactive": "Inactive"
    },
    "accessRequests": {
      "title": "Access Requests",
      "approve": "Approve",
      "reject": "Reject",
      "pending": "Pending",
      "approved": "Approved",
      "rejected": "Rejected",
      "rejectNotes": "Rejection notes (optional)"
    }
  }
}
```

---

## Usage in Components

```typescript
// Server Component
import { getTranslations } from 'next-intl/server';

export default async function CasesPage() {
  const t = await getTranslations('cases');
  return <h1>{t('title')}</h1>;
}

// Client Component
'use client';
import { useTranslations } from 'next-intl';

export function CaseFilters() {
  const t = useTranslations('cases');
  return <span>{t('filters.all')}</span>;
}

// With interpolation
t('detail.statusChange', { from: 'Pending', to: 'In Progress' })
// → "Status changed from Pending to In Progress"
```

---

## i18n Sync Rule

**Always add strings to all 3 locale files simultaneously.** When adding a new key to `en.json`, add the same key to `it.json` and `fr.json` in the same commit. Partial translations cause runtime errors from next-intl.

---

## Language Switcher Component

`src/components/layout/LanguageSwitcher.tsx`

```
┌──────────┐
│ 🇬🇧 EN  ▼ │
├──────────┤
│ 🇬🇧 English  │
│ 🇮🇹 Italiano │
│ 🇫🇷 Français │
└──────────┘
```

Uses `useRouter` from `src/navigation.ts` to navigate to the same path in the selected locale.

---

## Environment Variables

```bash
# Public — safe for browser (NEXT_PUBLIC_ prefix)
NEXT_PUBLIC_SUPABASE_URL=https://xxxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJ...
NEXT_PUBLIC_APP_URL=https://arcadiahub.com
NEXT_PUBLIC_APP_NAME=ArcadiaHub

# Server-only — NEVER in NEXT_PUBLIC_ variables
SUPABASE_SERVICE_ROLE_KEY=eyJ...
SUPABASE_PROJECT_ID=xxxx
RESEND_API_KEY=re_...
FROM_EMAIL=noreply@harlock.it
ADMIN_NOTIFICATION_EMAIL=admin@harlock.it
```

**Rules**:
- `NEXT_PUBLIC_*` — exposed to browser, safe for Supabase anon key and app URL
- No prefix — server-only, never sent to client bundle
- `SUPABASE_SERVICE_ROLE_KEY` **must never** appear in a `NEXT_PUBLIC_*` variable

---

## Application Configuration

### TypeScript (`tsconfig.json`)
```json
{
  "compilerOptions": {
    "strict": true,
    "paths": { "@/*": ["./src/*"] }
  }
}
```

### PostCSS (`postcss.config.mjs`)
```javascript
export default {
  plugins: { "@tailwindcss/postcss": {} },
};
```

### ESLint (`eslint.config.mjs`)
```javascript
import { FlatCompat } from '@eslint/eslintrc';
const compat = new FlatCompat({ ... });
export default [...compat.extends('next/core-web-vitals', 'next/typescript')];
```

---

## Structured Logger (`src/lib/logger.ts`)

```typescript
// Development: pretty-printed logs with level prefixes
// Production: JSON structured logs for log aggregation

const logger = {
  info(message: string, context?: Record<string, unknown>): void,
  warn(message: string, context?: Record<string, unknown>): void,
  error(message: string, context?: Record<string, unknown>): void,
  debug(message: string, context?: Record<string, unknown>): void,
};

export default logger;
```

---

## Date & Time

**Library**: `date-fns` v4.1.0

```typescript
import { format, formatDistanceToNow } from 'date-fns';

// Full date: "January 15, 2025"
format(date, 'MMMM d, yyyy')

// Short date: "Jan 15"
format(date, 'MMM d')

// Relative: "3 hours ago"
formatDistanceToNow(date, { addSuffix: true })

// ISO for Supabase: "2025-01-15T10:30:00Z"
new Date().toISOString()
```

All dates stored in UTC in Supabase; displayed in user's browser timezone.
