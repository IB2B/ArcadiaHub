# Server Actions Reference

There are no REST API endpoints. All data access and mutations are handled by **Next.js Server Actions** in `src/lib/data/`. Server Components call these functions directly; Client Components call them via form actions or `startTransition`.

> **Pattern**: Every mutation validates with Zod → checks auth/role → queries Supabase → calls `revalidatePath()` → returns `{ success, data?, error? }`.

---

## Auth (`src/lib/auth/actions.ts`)

| Function | Description |
|----------|-------------|
| `login(formData)` | Sign in with email + password; redirects to dashboard |
| `logout()` | Sign out, clear session, redirect to login |
| `forgotPassword(email)` | Send Supabase password reset email |
| `resetPassword(password)` | Update password with reset token |
| `updatePassword(current, new)` | Authenticated password change from settings |
| `submitAccessRequest(data)` | Insert access request; send received email + admin alert |
| `approveAccessRequest(id)` | Create Supabase user + send welcome email |
| `rejectAccessRequest(id, notes)` | Update status; send rejection email to applicant |

---

## Cases (`src/lib/data/cases.ts`)

| Function | Role | Description |
|----------|------|-------------|
| `getMyCases(options)` | PARTNER | List own cases with search/status filter |
| `getCases(options)` | ADMIN/COMMERCIAL | List all cases with filters |
| `getMyCase(caseId)` | Any | Single case with documents and history |
| `createCase(clientName, notes)` | PARTNER | Create new case; code from `next_case_code()` sequence |
| `updateCaseStatus(id, status)` | Any | Update status; triggers DB audit log; sends email to partner |
| `getCaseStats(partnerId?)` | Any | COUNT queries for dashboard stats widget |

---

## Events (`src/lib/data/events.ts` + `src/lib/data/admin.ts`)

| Function | Location | Role | Description |
|----------|----------|------|-------------|
| `getEvents(options)` | events.ts | Any | List published events with filters |
| `getEvent(id)` | events.ts | Any | Single event detail |
| `registerForEvent(eventId)` | events.ts | PARTNER | Register; enforces capacity limit |
| `unregisterFromEvent(eventId)` | events.ts | PARTNER | Cancel registration |
| `getEventRegistrations(eventId)` | events.ts | ADMIN/COMMERCIAL | List registrations for an event |
| `createEvent(data)` | admin.ts | ADMIN/COMMERCIAL | Create event; if published, blast email to all active partners |
| `updateEvent(id, data)` | admin.ts | ADMIN/COMMERCIAL | Update event; if flipping to published, send email blast |
| `deleteEvent(id)` | admin.ts | ADMIN/COMMERCIAL | Delete event + registrations |

---

## Academy (`src/lib/data/academy.ts` + `src/lib/data/admin.ts`)

| Function | Role | Description |
|----------|------|-------------|
| `getAcademyContent(options)` | Any | List published content with filters |
| `getAcademyItem(id)` | Any | Single content item; increments view count via RPC |
| `markContentComplete(contentId)` | PARTNER | Insert row in `content_completions` |
| `getMyCompletions()` | PARTNER | List user's completed content IDs |
| `createAcademyContent(data)` | ADMIN | Create content |
| `updateAcademyContent(id, data)` | ADMIN | Update content |
| `deleteAcademyContent(id)` | ADMIN | Delete content + completions |

---

## Documents (`src/lib/data/documents.ts` + `src/lib/data/admin.ts`)

| Function | Role | Description |
|----------|------|-------------|
| `getDocuments(options)` | Any | List published documents |
| `getDocument(id)` | Any | Single document; increments download count |
| `createDocument(data)` | ADMIN | Upload + create document |
| `updateDocument(id, data)` | ADMIN | Update document |
| `deleteDocument(id)` | ADMIN | Delete document + storage file |

---

## Blog (`src/lib/data/blog.ts` + `src/lib/data/admin.ts`)

| Function | Role | Description |
|----------|------|-------------|
| `getBlogPosts(options)` | Any | List published posts |
| `getBlogPost(slug)` | Any | Single post by slug; increments view count via RPC |
| `getCategories()` | Any | List all categories |
| `createBlogPost(data)` | ADMIN | Create post |
| `updateBlogPost(id, data)` | ADMIN | Update post |
| `deleteBlogPost(id)` | ADMIN | Delete post |
| `publishBlogPost(id)` | ADMIN | Set is_published = true; notify partners |

---

## Notifications (`src/lib/data/notifications.ts`)

| Function | Description |
|----------|-------------|
| `getNotifications()` | Current user's notification list |
| `getUnreadCount()` | Unread notification count (for bell badge) |
| `markAsRead(id)` | Mark single notification as read |
| `markAllAsRead()` | Mark all as read |
| `deleteNotification(id)` | Delete a notification |

Notifications are **created** server-side by `src/lib/services/notificationService.ts` using the service role client. They are **delivered** to the browser via Supabase Realtime subscription in `src/hooks/useNotifications.ts` — not polling.

---

## Profiles (`src/lib/data/profiles.ts`)

| Function | Role | Description |
|----------|------|-------------|
| `getProfile(id?)` | Any | Get own or any profile |
| `updateProfile(data)` | Any | Update own profile |
| `uploadProfileLogo(file)` | Any | Upload logo to `avatars` bucket |
| `getPartners(options)` | Any | Community directory listing |
| `getPartnerProfile(id)` | Any | Single partner detail |
| `updateNotificationPreferences(prefs)` | Any | Save email opt-out preferences |

---

## Suggestions (`src/lib/data/suggestions.ts`)

| Function | Role | Description |
|----------|------|-------------|
| `submitSuggestion(data)` | PARTNER | Insert suggestion; send confirmation email + admin alert |
| `getMySuggestions()` | PARTNER | Partner's own submissions |
| `getAllSuggestions(options)` | ADMIN/COMMERCIAL | All suggestions with filters |
| `updateSuggestionStatus(id, status, reply?)` | ADMIN/COMMERCIAL | Update status; optionally send reply email |

---

## Comments (`src/lib/data/comments.ts`)

| Function | Role | Description |
|----------|------|-------------|
| `getComments(entityType, entityId, page?)` | Any | Paginated comments for an entity |
| `createComment(data)` | Any | Create comment; process @mentions → notify + email each |
| `updateComment(id, content)` | Author | Edit own comment |
| `deleteComment(id)` | Author / ADMIN | Soft-delete if has replies; hard-delete if leaf |

---

## Admin (`src/lib/data/admin.ts`)

All functions require `ADMIN` or `COMMERCIAL` role via `requireAdminOrCommercial()` — **this must be refactored to use the shared `requireRole()` from `guards.ts` (Bug 14 fix)**.

Covers: partner CRUD, case CRUD, event CRUD, academy CRUD, document CRUD, blog CRUD, access request management, dashboard stats, sub-user creation.

---

## Notification Service (`src/lib/services/notificationService.ts`)

Uses the service role client. Called from server actions after mutations to create in-app notifications for the affected user(s).

| Function | Trigger |
|----------|---------|
| `notifyCaseCreated` | New case created |
| `notifyCaseStatusChanged` | Admin changes case status |
| `notifyCaseDocumentAdded` | Document added to case |
| `notifyEventPublished` | Admin publishes event |
| `notifyEventRegistration` | Partner registers for event |
| `notifyAcademyContentPublished` | New academy content |
| `notifyDocumentPublished` | New document available |
| `notifyBlogPostPublished` | New blog post published |
| `notifyAccessRequestSubmitted` | New access request |
| `notifyAccessRequestApproved` | Request approved |
| `notifyAccessRequestRejected` | Request rejected |
| `notifyUserMentioned` | User @mentioned in comment |
| `notifySuggestionReply` | Admin replied to suggestion |
