# Features & User Stories — Complete Reference

Every feature of ArcadiaHub organized by module, with user stories per role.

---

## Module 1: Authentication & Access

### Login
- **Any user**: I can log in with email and password
- **Any user**: I see an error message if credentials are invalid
- **Any user**: I am redirected to dashboard after login
- **Logged-in user**: I am redirected away from auth pages to dashboard

### Password Management
- **Any user**: I can click "Forgot Password?" to receive a reset email
- **Any user**: I can set a new password via the emailed link (Supabase one-time token)
- **Any user**: I can change my password from the settings page

### Access Request
- **Unauthenticated visitor**: I can submit an access request form (name, email, company, message)
- **Visitor**: After submission, I see a success confirmation
- **ADMIN**: I receive an in-app notification when a new access request is submitted

### Session Management
- **Any user**: My session is managed automatically by Supabase (HttpOnly cookies)
- **Any user**: I am redirected to login when my session expires
- **Any user**: I see a session-expired warning modal (`SessionTimeout.tsx`)

---

## Module 2: Dashboard

### Overview Stats
- **PARTNER**: I see stat cards: Total Cases, Pending, In Progress, Completed
- **ADMIN/COMMERCIAL**: I see platform-wide stats

### Recent Cases
- **PARTNER**: I see my 5 most recent cases with status badges
- **PARTNER**: I can click "View All" to go to the cases page

### Upcoming Events
- **PARTNER**: I see the next 3 upcoming events with date and type

### Activity Feed
- **PARTNER**: I see a chronological feed of recent platform activity (case updates, events, content, documents, blog posts)
- **PARTNER**: Each feed item has an icon, title, and relative timestamp

### Quick Actions
- **PARTNER**: I see quick action buttons for: Cases, Events, Docs, Academy, Community

---

## Module 3: Cases (Pratiche)

### Case List
- **PARTNER**: I see a list of my cases with: case code, client name, status badge, opened date
- **PARTNER**: I can search cases by code or client name
- **PARTNER**: I can filter cases by status (All, Pending, In Progress, Completed, Suspended, Cancelled)
- **PARTNER**: I see stat cards: Total, Pending, In Progress, Completed
- **PARTNER**: I can paginate through cases

### Case Detail
- **PARTNER**: I can view full case details: code, client, status, notes, opened/closed dates
- **PARTNER**: I see the case timeline (history of all status changes with timestamps)
- **PARTNER**: I see attached documents with download links

### Case Creation
- **PARTNER**: I can create a new case with: client name, notes (optional)
- **System**: A unique case code is auto-generated via PostgreSQL sequence (`next_case_code()`)
- **System**: Initial status is PENDING
- **System**: Admins are notified of new cases

### Case Status Updates
- **ADMIN/COMMERCIAL**: I can change a case's status
- **System**: Status changes are logged in `case_history` exclusively by DB trigger
- **System**: The partner is notified via in-app notification

### Admin Case Management
- **ADMIN/COMMERCIAL**: I see all cases across all partners
- **ADMIN**: I can create, edit, and delete cases from the admin panel
- **ADMIN**: I can upload documents to a case

---

## Module 4: Events

### Event List
- **PARTNER**: I see events in list view or calendar view (toggle)
- **PARTNER**: I can filter by: event type (webinar, training, conference), upcoming only
- **PARTNER**: I can search events by title
- **PARTNER**: I see event cards with: title, type badge, date/time, location

### Calendar View
- **PARTNER**: I can view events on a monthly calendar
- **PARTNER**: I can navigate between months
- **PARTNER**: I can click a day to see events on that day

### Event Detail
- **PARTNER**: I see full event details: title, type, description, date/time, location
- **PARTNER**: I can register and unregister for events
- **PARTNER**: I see a "Registered" badge if already registered
- **PARTNER**: I see current attendee count (when capacity is set)

### Admin Event Management
- **ADMIN/COMMERCIAL**: I can create, edit, and delete events
- **ADMIN**: Publishing an event sends in-app notifications to all partners
- **ADMIN**: I can see all registrations for an event

---

## Module 5: Academy

### Content List
- **PARTNER**: I see academy content in a card grid
- **PARTNER**: I can filter by content type (video, pdf, article, quiz) and category
- **PARTNER**: I can search by title
- **PARTNER**: Each card shows: thumbnail, title, type badge, duration, view count

### Content Detail
- **PARTNER**: I see full content: title, description, embedded media/download link
- **PARTNER**: I can mark content as complete (`markContentComplete()`)
- **PARTNER**: I see completion badge on completed items

### Admin Academy Management
- **ADMIN**: I can create, edit, and delete academy content
- **ADMIN**: Publishing content sends in-app notifications to all partners

---

## Module 6: Documents

### Document List
- **PARTNER**: I see documents with category filter tabs
- **PARTNER**: I can search documents by title
- **PARTNER**: Each document shows: title, description, file type, file size, date

### Document Detail
- **PARTNER**: I can preview and download documents
- **PARTNER**: Download count is incremented on download

### Admin Document Management
- **ADMIN**: I can create, edit, and delete documents
- **ADMIN**: Publishing a document sends in-app notifications to all partners

---

## Module 7: Blog

### Blog List
- **PARTNER**: I see published blog posts in a card grid
- **PARTNER**: Each card shows: cover image, title, excerpt, author, published date, category

### Blog Detail
- **PARTNER**: I see the full article with rendered content
- **PARTNER**: View count is incremented on each visit (atomic DB RPC)

### Admin Blog Management
- **ADMIN**: I can create, edit, and delete blog posts
- **ADMIN**: Publishing a post sends in-app notifications to all partners

---

## Module 8: Community

### Partner Directory
- **PARTNER**: I see all active partners in a card grid
- **PARTNER**: I can search by name or company
- **PARTNER**: I can filter alphabetically (A-Z letter bar)
- **PARTNER**: Each card shows: company logo, name, region, bio excerpt

### Partner Profile
- **PARTNER**: I can view another partner's public profile: company info, bio, contact details

---

## Module 9: Notifications

> ⚠️ **Bug 9**: `notifications/page.tsx` is missing. The route folder exists but the page renders nothing. Must create `page.tsx`.

### Notification Bell
- **PARTNER**: I see a bell icon in the header with unread count badge
- **System**: Unread count updates via Supabase Realtime subscription (replaces 30s polling — Bug 10 fix)

### Notification List (page.tsx — to create)
- **PARTNER**: Each notification shows: icon by type, title, message, timestamp, read/unread state
- **PARTNER**: I can click a notification to navigate to the related content
- **PARTNER**: I can mark a single notification as read
- **PARTNER**: I can mark all notifications as read

### Notification Types
| Trigger | Recipient | Type |
|---------|-----------|------|
| Case status changed | Case partner | `case_status_changed` |
| Case document added | Case partner | `case_document_added` |
| Event published | All partners | `event_published` |
| New academy content | All partners | `academy_content_published` |
| New document | All partners | `document_published` |
| New blog post | All partners | `blog_post_published` |
| Access request submitted | All ADMINs | `access_request_submitted` |
| Access request approved | Applicant | `access_request_approved` |
| Access request rejected | Applicant | `access_request_rejected` |
| @mention in comment | Mentioned user | `mention` |
| Admin replied to suggestion | Author | `suggestion_reply` |

---

## Module 10: Profile & Settings

### Profile Page
- **PARTNER**: I see my company information and contact details
- **PARTNER**: I can edit all profile fields (name, company, bio, phone, region)
- **PARTNER**: I can upload/change my company logo (`avatars` bucket)
- **PARTNER**: I see my role badge

### Settings Page
- **PARTNER**: I can switch between light and dark themes
- **PARTNER**: I can change the interface language (English, Italian, French)
- **PARTNER**: I can update notification preferences (per notification type email opt-out)

---

## Module 11: Admin Panel

### Admin Dashboard
- **ADMIN/COMMERCIAL**: I see platform-wide stats: Total Partners, Total Cases, Upcoming Events, Pending Access Requests
- **ADMIN**: Quick action links for creating Partners, Cases, Events, Content, Documents, Blog Posts

### Partner Management
- **ADMIN/COMMERCIAL**: Paginated table of all partners with search and filters
- **ADMIN**: Create new partner (triggers Supabase auth user creation + welcome email)
- **ADMIN**: Edit partner details and toggle active/inactive status
- **ADMIN**: Delete partner (with confirmation)
- **COMMERCIAL**: Create sub-users (PARTNER role) assigned to themselves

### Case Management (Admin)
- **ADMIN/COMMERCIAL**: See all cases with partner info
- **ADMIN**: Create, edit, delete cases; manage status; upload case documents

### Event Management
- **ADMIN/COMMERCIAL**: Create, edit, delete events; publish toggles trigger partner notifications

### Academy Management
- **ADMIN**: Create, edit, delete academy content; publish toggles trigger partner notifications

### Document Management
- **ADMIN**: Create, edit, delete documents with file upload; publish toggles trigger notifications

### Blog Management
- **ADMIN**: Create, edit, delete blog posts with rich content; publish triggers notifications

### Access Request Management
- **ADMIN/COMMERCIAL**: Table of access requests with status filter
- **ADMIN**: Approve → creates Supabase auth user + sends welcome email
- **ADMIN**: Reject → sends rejection email (to wire in Week 3)

---

## Module 12: Activity Feed

- **PARTNER**: I see a unified chronological feed from all content types
- **System**: Feed built from single PostgreSQL UNION ALL view (not N+1 queries — Bug 6 fix)

---

## Module 13: Public Pages

### Landing Page
- **Visitor**: Hero section with CTA (Access Portal / Request Access)
- **Visitor**: Feature grid showing platform modules
- **Visitor**: Platform stats section
- **Visitor**: Footer with links

### Privacy Policy & Terms
- **Visitor**: I can read the privacy policy and terms of service
