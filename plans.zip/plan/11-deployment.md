# Deployment

---

## Architecture

```
┌─────────────────────────────────┐
│   Vercel                        │  ← Next.js application
│   (Edge Network, Serverless)    │     SSR + Server Actions
└──────────────┬──────────────────┘
               │  Supabase SDK (HTTPS)
┌──────────────▼──────────────────┐
│   Supabase Cloud                │  ← All backend services
│   ┌─────────┐  ┌─────────────┐  │
│   │PostgreSQL│  │GoTrue Auth  │  │
│   └─────────┘  └─────────────┘  │
│   ┌─────────┐  ┌─────────────┐  │
│   │ Storage │  │  Realtime   │  │
│   └─────────┘  └─────────────┘  │
└─────────────────────────────────┘
               │
┌──────────────▼──────────────────┐
│   Resend                        │  ← Transactional email
└─────────────────────────────────┘
```

There are no Docker containers, no Spring Boot servers, no separate API to deploy.

---

## Environments

| Environment | Next.js | Supabase | Purpose |
|-------------|---------|----------|---------|
| Local dev | `npm run dev` (localhost:3000) | Local Supabase CLI or cloud dev project | Development |
| Preview | Vercel preview deployment | Dev Supabase project | PR review |
| Production | Vercel production deployment | Supabase production project | Live |

---

## Vercel Setup

1. Connect the GitHub repository to Vercel
2. Set framework preset: **Next.js**
3. Set all environment variables in Vercel dashboard (not in committed files)
4. Every push to `main` triggers a production deployment
5. Every pull request gets an automatic preview deployment URL

---

## Supabase Setup

1. Create a Supabase project at supabase.com
2. Apply migrations via Supabase CLI:
   ```bash
   supabase db push
   ```
3. Enable Realtime on the `notifications` table in the Supabase dashboard (Table Editor → Replication)
4. Create storage buckets: `avatars` (public), `case-documents`, `academy-content`, `documents`, `blog-images`, `event-images`
5. Set storage bucket policies (public buckets: allow read; private buckets: require signed URLs)

---

## Environment Variables

Set these in **Vercel dashboard** (never commit `.env.local`):

```bash
# Public — safe to expose to browser
NEXT_PUBLIC_SUPABASE_URL=https://xxxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJ...
NEXT_PUBLIC_APP_URL=https://arcadiahub.com
NEXT_PUBLIC_APP_NAME=ArcadiaHub

# Server-only — NEVER in NEXT_PUBLIC_* variables
SUPABASE_SERVICE_ROLE_KEY=eyJ...
SUPABASE_PROJECT_ID=xxxx
RESEND_API_KEY=re_...
FROM_EMAIL=noreply@harlock.it
ADMIN_NOTIFICATION_EMAIL=admin@harlock.it
PARTNER_BULK_EMAIL_ENABLED=true
```

---

## Email: Resend DNS Verification

Start this in **Week 1** — DNS propagation can take up to 48 hours.

1. Add your sending domain in the Resend dashboard
2. Add the provided TXT and CNAME records to your DNS provider
3. Wait for verification (check status in Resend dashboard)
4. Set `FROM_EMAIL` to an address at the verified domain

---

## Database Migrations

Apply migrations in order before deploying:

```bash
# Check current migration status
supabase db status

# Apply all pending migrations
supabase db push

# Migration order (rename 002_fix_rls_recursion.sql to 003_ first):
# 001_initial_schema.sql
# 002_access_requests.sql
# 003_fix_rls_recursion.sql    ← renamed from 002_fix_rls_recursion.sql
# 003_schema_fixes_and_performance.sql
# 004_missing_tables.sql       ← must create this file
```

---

## Deployment Checklist

Before going to production:

- [ ] All 5 migration files applied cleanly on production Supabase project
- [ ] Realtime enabled on `notifications` table
- [ ] All 6 storage buckets created with correct policies
- [ ] Resend domain verified and `FROM_EMAIL` set
- [ ] All server-only env vars set in Vercel dashboard
- [ ] `SUPABASE_SERVICE_ROLE_KEY` is NOT in any `NEXT_PUBLIC_*` variable
- [ ] `npm run build` passes locally with no TypeScript errors
- [ ] `npm run lint` passes with no errors
- [ ] End-to-end test: login as each role, complete a core flow
