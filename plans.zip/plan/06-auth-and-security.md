# Authentication & Security

---

## Authentication Architecture

Authentication is handled entirely by **Supabase GoTrue**. There is no custom JWT implementation.

```
Browser
  │  form submit
  ▼
Next.js Server Action (src/lib/auth/actions.ts)
  │  1. Zod validates form data
  │  2. supabase.auth.signInWithPassword({ email, password })
  │  3. Supabase sets session cookie automatically (HttpOnly)
  │  4. redirect('/[locale]/dashboard')
  ▼
Next.js Middleware (src/middleware.ts)
  │  On every request: supabase.auth.getUser()
  │  If no session → redirect to /[locale]/login
  │  If session → attach to request context
  ▼
Server Component / Server Action
  │  createClient() reads session cookie
  │  All queries respect RLS automatically
  ▼
Supabase PostgreSQL
  │  RLS policies: auth.uid() = partner_id, etc.
  │  Enforced at DB level — impossible to bypass via app code
```

---

## Three Security Layers

### 1. Middleware (Route Protection)
`src/middleware.ts` calls `supabase.auth.getUser()` on every request to protected paths. Redirects to login if no valid session.

Protected path groups:
- `/[locale]/(dashboard)/*` — requires any authenticated session
- `/[locale]/(admin)/admin/*` — requires ADMIN or COMMERCIAL role

> **Important**: Always use `getUser()`, never `getSession()`. `getSession()` reads from the cookie without server-side validation and can be spoofed.

### 2. Server Action Layer (Auth Guards)
`src/lib/auth/guards.ts` exports:

```typescript
// Throws if not authenticated
export async function requireAuth(): Promise<{ userId: string; profile: Profile }>

// Throws if not authenticated or role not in the list
export async function requireRole(roles: string[]): Promise<{ userId: string; profile: Profile }>
```

Every server action that writes data must call one of these at the top. **Do not use inline role checks** — both `admin.ts` and `accessRequests.ts` currently do this (Bugs 7 and 14); they must be refactored.

### 3. Database Layer (Row Level Security)
Every table has RLS enabled. Policies ensure:
- Partners can only SELECT rows where `partner_id = auth.uid()` or `user_id = auth.uid()`
- INSERT operations enforce ownership automatically
- ADMIN/COMMERCIAL role is checked via a subquery on `profiles`

RLS is the last line of defense and is enforced even if application code has a bug.

---

## Password Reset Flow

```
1. User submits forgot-password form
2. forgotPassword() calls supabase.auth.resetPasswordForEmail(email, { redirectTo })
3. Supabase sends email with one-time reset link
4. User clicks link → lands on /[locale]/reset-password
5. resetPassword() calls supabase.auth.updateUser({ password: newPassword })
6. redirect('/[locale]/login')
```

---

## Access Request Flow

```
1. Applicant submits form at /[locale]/request-access
2. submitAccessRequest():
   a. Insert row in access_requests (status = 'pending')
   b. Send confirmation email to applicant (sendAccessRequestReceivedEmail)
   c. Send admin alert to ADMIN_NOTIFICATION_EMAIL (sendAdminAlertEmail)
   d. Create in-app notification for all ADMIN users (notifyAccessRequestSubmitted)

3. Admin reviews in /admin/access-requests

4a. approveAccessRequest(id):
    a. supabase.auth.admin.createUser({ email, email_confirm: true })
       [uses service role client — only place this is needed]
    b. Upsert profile with role = PARTNER
    c. Send welcome email with setup link (sendPartnerWelcomeEmail)  ← already implemented
    d. Update access_requests status = 'approved'

4b. rejectAccessRequest(id, notes):
    a. Update status = 'rejected', review_notes = notes
    b. Send rejection email to applicant (sendAccessRequestRejectionEmail)  ← must be wired
```

---

## Sub-User Creation Flow (COMMERCIAL)

```
1. COMMERCIAL opens /admin/partners → "Create User" button
2. CreateSubUser():
   a. requireRole(['ADMIN', 'COMMERCIAL'])
   b. COMMERCIAL can only create PARTNER role accounts
   c. supabase.auth.admin.createUser({ email, email_confirm: true })
   d. Upsert profile: role = PARTNER, assigned_commercial_id = caller.id, created_by = caller.id
   e. supabase.auth.admin.generateLink({ type: 'recovery' }) → setup link
   f. sendUserInviteEmail(email, firstName, setupLink)
   g. revalidatePath('/[locale]/(admin)/admin/partners')
```

---

## Service Role Client Rules

`createServiceSupabaseClient()` bypasses RLS. Only two files may use it:

| File | Why |
|------|-----|
| `notificationService.ts` | Must insert notifications for arbitrary users |
| `accessRequests.ts` | Must call `supabase.auth.admin` to create/manage auth users |

All other server actions use `createClient()` (session-aware, RLS-enforced).

**Never put `SUPABASE_SERVICE_ROLE_KEY` in a `NEXT_PUBLIC_*` variable.**

---

## Role Guards — Correct Pattern

```typescript
// ✅ Correct — use the shared helper
import { requireRole } from '@/lib/auth/guards';

export async function adminAction() {
  await requireRole(['ADMIN', 'COMMERCIAL']);
  // ...
}

// ❌ Wrong — inline check (exists in admin.ts and accessRequests.ts, must be fixed)
const profile = await getCurrentProfile();
if (!profile || !['ADMIN', 'COMMERCIAL'].includes(profile.role)) {
  throw new Error('Unauthorized');
}
```

---

## Email Security

- All email is sent via Resend API from the server — the API key is never exposed to the browser
- `FROM_EMAIL` must use a domain verified in Resend (start DNS verification in Week 1)
- `ADMIN_NOTIFICATION_EMAIL` is stored as a server-only environment variable
